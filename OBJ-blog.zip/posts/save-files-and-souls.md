---
title: Save Files & Souls: Memory Cards as Philosophy of Self
date: 2005-10-12
tags: [metaphysics, ps2, identity]
category: metaphysics
excerpt: If identity is a save slot, what are we doing when we overwrite? A meditation featuring Metal Gear Solid 2 and Parfit.
---

We talk about *identity* like a character select screen. When you overwrite the save, did you **kill** the past you? Derek Parfit would say that identity is not what matters—*psychological continuity* is.

- **Memory card** = externalized continuity.
- **Permadeath** modes = ethical laboratories.
- **NG+** = eternal return with load-outs.

> The boss fight is recognizing you were never the protagonist, just a player of roles.