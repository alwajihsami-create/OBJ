---
title: Patch Notes for Being: Version 1.0.1
date: 2007-01-21
tags: [ethics, updates, modding]
category: ethics
excerpt: Changelog thoughts: minor bug fixes to virtue ethics; buffed courage; nerfed cynicism.
---

- **Courage** +5% when supporting friends’ creative projects.
- **Cynicism** damage over time reduced (see community feedback).
- **Hope** now stacks with **Patience** (syncretic synergy).