---
title: Lag, Latency, and the Phenomenology of Input Delay
date: 2006-03-08
tags: [phenomenology, arcade, timing]
category: phenomenology
excerpt: On missing a just-frame by 16ms and why Husserl might rage-quit Tekken 5.
---

Latency shreds the unity of consciousness. The *intentional arc* from button to action gets stretched thin.

1. **Retention** (what just happened) blurs with the frame buffer.
2. **Primal impression** (now) drifts into **protention** (anticipation).
3. Suddenly the combo drops—*and so does certainty*.