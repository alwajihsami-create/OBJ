
import React, { useMemo, useState, useEffect } from 'react'
import matter from 'gray-matter'
import { marked } from 'marked'

// Load all markdown posts
the get?
const rawPosts = import.meta.glob('../posts/**/*.md', { as: 'raw', eager: true })
const postEntries = Object.entries(rawPosts).map(([path, raw]) => {
  const { data, content } = matter(raw)
  const slug = path.replace('../posts/', '').replace(/\.md$/, '')
  return { ...data, slug, content }
}).sort((a, b) => (new Date(b.date) - new Date(a.date)))

function useHashRoute() {
  const [hash, setHash] = useState(window.location.hash || '#/')
  useEffect(() => {
    const onHash = () => setHash(window.location.hash || '#/')
    window.addEventListener('hashchange', onHash)
    return () => window.removeEventListener('hashchange', onHash)
  }, [])
  return hash
}

function PixelButton({ children, active=false, onClick }) {
  return (
    <button
      onClick={onClick}
      className={[
        'px-3 py-1 text-xs tracking-wider uppercase',
        'bg-[#1a1a1a] text-[#c5ffc5] border border-[#59ff59]',
        'shadow-[2px_2px_0_0_#59ff59,4px_4px_0_0_#0f0]',
        active ? 'animate-pulse' : 'hover:translate-x-[1px] hover:translate-y-[1px]',
        'transition-transform',
      ].join(' ')}
      style={{ imageRendering: 'pixelated' }}
    >
      {children}
    </button>
  )
}

function CrtFrame({ children }) {
  return (
    <div className="relative border border-[#33ff33] bg-black/80 overflow-hidden">
      <div className="pointer-events-none absolute inset-0 mix-blend-overlay opacity-20" style={{
        backgroundImage:
          'repeating-linear-gradient(0deg, rgba(255,255,255,0.08) 0, rgba(255,255,255,0.08) 1px, transparent 2px, transparent 4px)',
      }} />
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(51,255,51,0.12)_0%,rgba(0,0,0,0.85)_70%)]" />
      <div className="relative">{children}</div>
    </div>
  )
}

function NeonDivider() {
  return <div className="h-[1px] w-full bg-gradient-to-r from-transparent via-[#33ff33] to-transparent my-4" />
}

function PostCard({ post }) {
  return (
    <article className="group border border-[#33ff33]/70 bg-black/60 p-4 mb-4 hover:bg-black/80 transition-colors">
      <a href={`#/post/${post.slug}`}>
        <h3 className="text-[#99ff99] text-lg md:text-xl font-bold group-hover:text-white">
          {post.title}
        </h3>
      </a>
      <div className="text-[#59ff59] text-[11px] uppercase tracking-widest mt-1">
        {new Date(post.date).toLocaleDateString()}
      </div>
      <p className="text-[#c8ffc8] text-sm mt-2">{post.excerpt}</p>
      <div className="mt-3 flex flex-wrap gap-2">
        {post.category && (<span className="text-[10px] px-2 py-0.5 border border-[#59ff59] text-[#baffba] bg-black/60">@{post.category}</span>)}
        {(post.tags || []).map((t) => (
          <span key={t} className="text-[10px] px-2 py-0.5 border border-[#59ff59] text-[#baffba] bg-black/60">
            #{t}
          </span>
        ))}
      </div>
    </article>
  )
}

function Marquee({ text }) {
  return (
    <div className="overflow-hidden whitespace-nowrap border-y border-[#33ff33]/60">
      <div className="inline-block animate-[marquee_18s_linear_infinite] text-[#baffba] text-xs py-1">
        <span className="mx-6">{text}</span>
        <span className="mx-6">{text}</span>
        <span className="mx-6">{text}</span>
      </div>
      <style>{`
        @keyframes marquee { from { transform: translateX(0); } to { transform: translateX(-50%); } }
      `}</style>
    </div>
  )
}

function Sidebar() {
  return (
    <aside className="space-y-4">
      <CrtFrame>
        <div className="p-4">
          <h4 className="text-[#99ff99] font-bold uppercase tracking-wider text-sm">About</h4>
          {/* blank mysterious information intentionally left empty */}
          <p className="text-[#c8ffc8] text-sm mt-2"></p>
        </div>
      </CrtFrame>
      <CrtFrame>
        <div className="p-4">
          <h4 className="text-[#99ff99] font-bold uppercase tracking-wider text-sm">Webring</h4>
          <div className="grid grid-cols-2 gap-2 mt-3">
            {['VALID HTML','RSS FEED','NO POPUPS','MYSTERIOUS'].map((label) => (
              <div key={label} className="w-[88px] h-[31px] border border-white/40 flex items-center justify-center text-[9px] font-bold tracking-wider bg-[#222]" style={{ imageRendering:'pixelated' }}>
                <span className="uppercase text-white drop-shadow-[0_1px_0_rgba(0,0,0,0.8)]">{label}</span>
              </div>
            ))}
          </div>
        </div>
      </CrtFrame>
      <CrtFrame>
        <div className="p-3 flex items-center justify-center">
          <span className="text-[#baffba] text-[10px] uppercase">© {new Date().getFullYear()} OBJ</span>
        </div>
      </CrtFrame>
    </aside>
  )
}

export default function App() {
  const hash = useHashRoute()

  let page = 'home', slug = null
  const m = hash.match(/^#\/post\/(.+)$/)
  if (m) { page = 'post'; slug = decodeURIComponent(m[1]) }
  else if (hash.startsWith('#/posts')) page = 'posts'

  const posts = useMemo(() => postEntries, [])
  const current = posts.find(p => p.slug === slug)

  return (
    <div className="min-h-screen text-[#d9ffd9]" style={{
      backgroundImage:
        'radial-gradient(circle at 20% 10%, rgba(0,255,0,0.08), transparent 25%), radial-gradient(circle at 80% 30%, rgba(0,255,0,0.06), transparent 20%), radial-gradient(circle at 50% 90%, rgba(0,255,0,0.05), transparent 25%)',
      backgroundColor: '#0a0a0a',
      cursor: 'crosshair',
    }}>
      <Marquee text={"WELCOME TO OBJ • LO-FI GAMES & HI-FI THOUGHTS • BE NICE • USE RSS • NO SPOILERS AFTER 2007 •"} />

      <header className="max-w-6xl mx-auto px-4 mt-6">
        <div className="relative">
          <div className="absolute -inset-1 bg-[#33ff33]/20 blur" />
          <div className="relative border border-[#33ff33] p-4 bg-black/70">
            <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-3">
              <div>
                <h1 className="text-3xl md:text-5xl font-black leading-none text-transparent bg-clip-text bg-gradient-to-r from-[#9aff9a] via-white to-[#9aff9a]">
                  O<span className="text-[#33ff33]">BJ</span>
                </h1>
                <p className="text-xs md:text-sm uppercase tracking-widest text-[#baffba]">An OBJ appeared.</p>
              </div>
              <div className="flex gap-2">
                <PixelButton active={page==='home'} onClick={() => {window.location.hash = '#/'}}>Home</PixelButton>
                <PixelButton active={page==='posts'} onClick={() => {window.location.hash = '#/posts'}}>Posts</PixelButton>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 mt-6 grid grid-cols-1 md:grid-cols-3 gap-6">
        <section className="md:col-span-2 space-y-6">
          {page === 'home' && (
            <CrtFrame>
              <div className="p-4">
                <h2 className="text-[#99ff99] text-xl font-bold uppercase tracking-wider">Latest Posts</h2>
                <NeonDivider />
                {posts.map((p) => (<PostCard key={p.slug} post={p} />))}
              </div>
            </CrtFrame>
          )}

          {page === 'posts' && (
            <CrtFrame>
              <div className="p-4">
                <h2 className="text-[#99ff99] text-xl font-bold uppercase tracking-wider">All Posts</h2>
                <NeonDivider />
                {posts.map((p) => (<PostCard key={p.slug} post={p} />))}
              </div>
            </CrtFrame>
          )}

          {page === 'post' && current && (
            <CrtFrame>
              <div className="p-4 space-y-3">
                <a href="#/posts" className="text-[#baffba] text-xs uppercase tracking-widest">← Back to posts</a>
                <h2 className="text-[#99ff99] text-2xl font-bold">{current.title}</h2>
                <div className="text-[#59ff59] text-[11px] uppercase tracking-widest">
                  {new Date(current.date).toLocaleDateString()}
                </div>
                {current.cover && (
                  <img src={current.cover.startsWith('http') ? current.cover : (current.cover.startsWith('/uploads') ? current.cover : `/uploads/${current.cover}`)} alt="" className="w-full mt-2 border border-[#33ff33]/60" />
                )}
                {current.video_url && (
                  <div className="mt-3 aspect-video">
                    <iframe src={current.video_url} className="w-full h-full" allowFullScreen></iframe>
                  </div>
                )}
                {current.video_file && (
                  <video className="w-full mt-3" controls src={current.video_file.startsWith('/uploads') ? current.video_file : `/uploads/${current.video_file}`}></video>
                )}
                <div className="prose prose-invert max-w-none"
                  dangerouslySetInnerHTML={{ __html: marked.parse(current.content) }} />
              </div>
            </CrtFrame>
          )}

          {page === 'post' && !current && (
            <CrtFrame><div className="p-4">Post not found.</div></CrtFrame>
          )}
        </section>

        <Sidebar />
      </main>

      <footer className="max-w-6xl mx-auto px-4 mt-6 mb-12">
        <div className="border border-[#33ff33] bg-black/70 p-3 text-center text-[11px] text-[#baffba] uppercase tracking-widest">
          Made with ❤, HTML feelings, and CRT glow. RSS soon.
        </div>
      </footer>

      <div className="pointer-events-none fixed inset-0 opacity-10" style={{
        backgroundImage:
          'repeating-linear-gradient(0deg, rgba(255,255,255,0.08) 0, rgba(255,255,255,0.08) 1px, transparent 2px, transparent 4px)',
      }} />
    </div>
  )
}
